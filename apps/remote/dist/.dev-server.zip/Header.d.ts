export * from './compiled-types/components/Header/index';
export { default } from './compiled-types/components/Header/index';