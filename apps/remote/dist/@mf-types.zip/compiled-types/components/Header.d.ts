import React from 'react';
interface HeaderProps {
    title: string;
}
declare const Header: React.FC<HeaderProps>;
export default Header;
