import React from 'react';
import './Header.scss';
interface HeaderProps {
    title: string;
}
declare const Header: React.FC<HeaderProps>;
export default Header;
